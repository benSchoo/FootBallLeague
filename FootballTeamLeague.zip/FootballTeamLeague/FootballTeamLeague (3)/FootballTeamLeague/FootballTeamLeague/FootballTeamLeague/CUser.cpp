#include "CUser.h"

CUser::CUser(void) {
	m_User = "";
	m_Password = 0;
	m_Account = '\0';
}
CUser::CUser(string User) {
	m_User = User;
	m_Password = 0;
	m_Account = '\0';
}
CUser::CUser(string User,int Password, char Account) {
	m_User = User;
	m_Password = Password;
	m_Account = Account;
}
void CUser::SetUser(string User) {
	m_User = User;
}

void CUser::SetPassword(int Password) {
	m_Password = Password;
}

void CUser::SetAccount(char Account) {
	m_Account = Account;
}
string CUser::GetUser(void) {
	return m_User;
}

int CUser::GetPassword(void) {
	return m_Password;
}

char CUser::GetAccount(void) {
	return m_Account;
}

bool  CUser::HasUser(string User) {
	if (m_User==User)
	{
		return true;
	}
	else {
		return false;
	}
}
bool  CUser::HasPassword(int Password) {
	if (m_Password == Password)
	{
		return true;
	}
	else {
		return false;
	}
}

bool CUser::ValidPass(string User, int Password) { //logic to check for valid input of password
	if (HasUser(User)==true&&HasPassword(Password)==true)
	{
		return true;
	}
	else
	{
		return false;
	}
}