#pragma once
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <Windows.h>
#include <limits>
using namespace std;
class CFootballTeam
{
private:
	string m_Name;
	int m_GamesPlayed;
	int m_GoalsFor;
	int m_GoalsAgainst;
	int m_Points;
public:

	CFootballTeam(void);
	CFootballTeam(string name);
	CFootballTeam(string name, int GamesPlayed, int GoalsFor,int GoalsAgainst,int Points);

	void SetGamesPlayed(int GamesPlayed);

	void SetGoalsFor(int GoalsFor);

	void SetGoalsAgainst(int GoalsAgainst);

	void SetPoints(int Points);

	string GetName(void);

	int GetGamesPlayed(void);

	int GetGoalsFor(void);

	int GetGoalsAgainst(void);

	int GetPoints(void);
	void UpdateResult(int goals1);
	void UpdateAgainst(int goals1);
	bool HasName(string searchName);
	void ClearValue();
};