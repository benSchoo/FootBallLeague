#pragma once
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <istream>
using namespace std;
class CUser
{
private:
	string m_User;
	int m_Password;
	char m_Account;

public:

	CUser(void);
	CUser(string User);
	CUser(string User, int Password, char Account);

	void SetUser(string User);

	void SetPassword(int Password);

	void SetAccount(char Account);

	string GetUser(void);

	int GetPassword(void);

	char GetAccount(void);

	bool HasUser(string User);
	bool HasPassword(int Password);
	bool ValidPass(string User, int Password);
};