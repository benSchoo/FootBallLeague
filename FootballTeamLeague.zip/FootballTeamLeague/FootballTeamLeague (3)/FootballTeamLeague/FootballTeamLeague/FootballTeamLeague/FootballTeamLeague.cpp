#include "CFootballTeam.h"
#include "CUser.h"
CFootballTeam  list[25];
CUser logs[40];
CUser storage[40];
int leagueMembers = 0;
int UserAcc = 0;
int attempts = 3;
int option,passwords,mChoice,aChoice;
string users, blank;
bool errorCheck;
char acc,quit='y';
char emptys;
void writein(void);
void writein2(void);
void DoDisplayLeague(void);
void Displays(void);
void FirstMenu(void);
void MenuClear(void);
void makeMenu(char acc);
void ManagerMenu(void);
void AssistantMenu(void);
void DoEnterMatchResult(void);
void DoInitializeTeamList(void);
void DoRemoveTeamFromList(void);
void clearInputBuffer(void);
void DoDeductPoints(void);
void DoBestDefence(void);
void DoRelegationZone(void);
void DoAddTeamToList();
void DoAddUser(void);
void DoEditUser(void);
int validator(int option);
void writeout(void);
void SaveChanges(void);
void DoQuit(void);

int main()
{
	writein();
	writein2();
	cout << "\033[94m";// ansi code to change the color of the text of the program to light blue

	
		FirstMenu();
		cin >> option;
		option = validator(option);
		switch (option)
		{
		case 1: {
			MenuClear();
			cout << "Please enter your username, your password\n";
			do 
			{
				errorCheck = false; // for the error message of a wrong input
				cin >> users;
				cin >> passwords;
				passwords = validator(passwords);
				for (int i = 0; i < UserAcc; i++)
				{
					acc = logs[i].GetAccount();
					if (logs[i].ValidPass(users, passwords) == true)
					{
						errorCheck=true; //makes error chek through to stop the incorrect message looping everytime in the loop till it reaches the correct one
						makeMenu(acc);
						break;
					}
				}
				if (!errorCheck) 
				{
					cout << "Incorrect username, password. Please try again\n";
					clearInputBuffer();
					MenuClear();
				}
			} while (quit != 'x');
			break;
		}
		case 2: {
			cout << "Goodbye thank you for using the program.";
			break;
		}
		default:
			cout << "Goodbye thank you for using the program.";
			break;
		
		} 
	
	cout << "\033[0m"; // ansi code to reset the text color to white before the final writeout
	writeout();
	return 0;
	
}


void writein() { //reads in from the file for the league information
	ifstream infile("LeagueInfo.dat");
	if (!infile)
	{
		cout << "database file LeagueInfo.dat does not exist\n";
		cout << "You should use Initialize Team List menu option to add 4 teams to the list \n";
	}
	else
	{
		string name;
		int GamesPlayed, GoalsFor, GoalsAgainst, Points;

		infile >> leagueMembers;

		for (int i = 0; i < leagueMembers; i++)
		{
			infile >> name >> GamesPlayed >> GoalsFor >> GoalsAgainst >> Points;
			CFootballTeam league(name, GamesPlayed, GoalsFor, GoalsAgainst, Points);
			list[i] = league;
		}
	}
}
void writein2() { // reads in from the user file
	ifstream Userfile("UserInfo.dat");
	if (!Userfile)
	{
		cout << "database file UserInfo.dat does not exist\n";
		cout << "You should use AddUser menu option to add 4 users to the logs \n";
	}
	else
	{
		string User;
		int Password;
		char Account;
		Userfile >> UserAcc;

		for (int i = 0; i < UserAcc; i++)
		{
			Userfile >> User >> Password >> Account;
			CUser storage(User, Password, Account);
			logs[i] = storage;
		}
	}
}
void DoInitializeTeamList(void) { //initiliazes the team list if there is none available and prompts the user yes or no if they want to delete the current one
	string names;
	char listCheck;
	ifstream CheckList("LeagueInfo.dat");
	if (!CheckList)
	{
		cout << "no data found";
	}
	else {
		CheckList.seekg(0, ios::end);
		if (CheckList.tellg() == 0) {
			

			cout << "There has been no teams found in your list please enter the amount of teams you would like for your list\n";
			cin >> leagueMembers;
			leagueMembers = validator(leagueMembers);
			for (int i = 0; i < leagueMembers; i++)
			{
				MenuClear();
				int gamesplay = 0;
				int goalsfor = 0;
				int goalsagainst = 0;
				int points = 0;
				cout << "Please enter the name of the team you want:\n";
				cin.ignore();
				getline(cin, names);
				cout << "Please enter the games played by the team\n";
				cin >> gamesplay;
				gamesplay = validator(gamesplay);
				cout << "Please enter the goals for the team\n";
				cin >> goalsfor;
				goalsfor = validator(goalsfor);
				cout << "Please enter the goals scored against the team\n";
				cin >> goalsagainst;
				goalsagainst = validator(goalsagainst);
				cout << "Please enter the teams points\n";
				cin >> points;
				points = validator(points);
				CFootballTeam league(names, gamesplay, goalsfor, goalsagainst, points);
				list[i] = league;
			}
		}
		else {
			cout << "would you like to delete the current list of teams Y/N\n";
			cin >> listCheck;
			if (tolower(listCheck) == 'y')
			{
				cout << "list succesfully deleted please re enter the option in the menu to add a new list\n";
				ofstream file("LeagueInfo.dat", ios::out | ios::trunc); // ios::trunc clears everything from the LeagueInfo.dat file resetting it for the new list 
				file.close();
			}
			else if (tolower(listCheck) == 'n')
			{
				cout << "bringing back to menu\n";
			}
			else
			{
				cout << "error";
			}
		}
		
	}
	writeout();
}
void DoDisplayLeague(void) { //displays the league members
	writein();
	for (int i = 0; i < leagueMembers; i++)
	{
		cout << list[i].GetName() << " " << list[i].GetGamesPlayed() << " " << list[i].GetGoalsFor() << " " << list[i].GetGoalsAgainst() << " " << list[i].GetPoints() << endl;
	}
}
void Displays(void) {
	for (int i = 0; i < UserAcc; i++)
	{
		cout << logs[i].GetUser() << " " << logs[i].GetPassword() << " " << logs[i].GetAccount() << endl;
	}
}
void FirstMenu() { //menu art for the first prompt
	cout << "+---------------------------------+" << endl;
	cout << "|          Welcome to the         |" << endl;
	cout << "|          Football league        |" << endl;
	cout << "+---------------------------------+" << endl;
	cout << "| 1. Enter Program                |" << endl;
	cout << "| 2. Exit                         |" << endl;
	cout << "+---------------------------------+" << endl;
	cout << "Select an option: ";
}
void MenuClear() { // clears the console screen
	system("cls");
}
void ManagerMenu() { // menu art done for the manager menu 
	cout << "+---------------------------------+" << endl;
	cout << "|          Welcome to the         |" << endl;
	cout << "|          Football league        |" << endl;
	cout << "|           Manager Menu          |" << endl;
	cout << "+---------------------------------+" << endl;
	cout << "| 1.  Initialize Team List        |" << endl;
	cout << "| 2.  Display League Table        |" << endl;
	cout << "| 3.  Enter a Match Result        |" << endl;
	cout << "| 4.  Deduct Points               |" << endl;
	cout << "| 5.  Best Defence                |" << endl;
	cout << "| 6.  Relegation Zone             |" << endl;
	cout << "| 7.  Add Team to List            |" << endl;
	cout << "| 8.  Remove Team from List       |" << endl;
	cout << "| 9.  Add User                    |" << endl;
	cout << "| 10. Edit User                   |" << endl;
	cout << "| 0.  Exit                        |" << endl;
	cout << "+---------------------------------+" << endl;
	cout << "Select an option: ";
}
void AssistantMenu() { //menu art done for the assistant menu
	cout << "+---------------------------------+" << endl;
	cout << "|         Welcome to the          |" << endl;
	cout << "|         Football league         |" << endl;
	cout << "|		   Asssistant Menu         |" << endl;
	cout << "+---------------------------------+" << endl;
	cout << "| 1. Display League Table         |" << endl;
	cout << "| 2. Enter a Match Result         |" << endl;
	cout << "| 3. Best Defence                 |" << endl;
	cout << "| 4. Relegation Zone              |" << endl;
	cout << "| 0. Exit                         |" << endl;
	cout << "+---------------------------------+" << endl;
	cout << "Select an option: ";
}
void clearInputBuffer() { // clears input bufferss for the functions as it allows the user to enter a blank space before the menu clears to stop the results of the function instantly disappearing
	getline(cin, blank);
	getline(cin, blank);
}
void DoDeductPoints() { // searches the collection for the team with the name you enter and it deducts points from it
	writein();
	bool deductCheck = false;
	int deduct;
	string name;
	cout << "Please enter the name of the club you would like to deduct points from.\n";
	cin >> name;
	cout << "Please enter the amount of points you would like to deduct.\n";
	cin >> deduct;
	for (int i = 0; i < leagueMembers; i++)
	{
		if (list[i].HasName(name) == true)
		{
			deductCheck = true;
			int deduction = list[i].GetPoints() - deduct;
			list[i].SetPoints(deduction);
			cout << "Succesfully deducted " << deduct << " points from " << name << ".\n";
			break;
		}
	}
	if (!deductCheck)
	{
		cout << "No team with the name: " << name << " found please try again.\n";
		clearInputBuffer();
	}
	writeout();
}
void DoBestDefence(){ //shows the team with the lowest goals scored against them
	int BestDefence = list[0].GetGoalsAgainst();
	for (int i = 0; i < leagueMembers; i++)
	{
		if (BestDefence>list[i].GetGoalsAgainst())
		{
			BestDefence = list[i].GetGoalsAgainst();
		}
	}

	for (int i = 0; i < leagueMembers; i++)
	{
		if (BestDefence==list[i].GetGoalsAgainst())
		{
			cout << "The Team with the best defence is " << list[i].GetName() << " with " << list[i].GetGoalsAgainst() << " goals against them.";
			break;
		}
	}
	writeout();
}
void DoRelegationZone(void) { //shows the bottom three in the league in terms of points
	int first = list[0].GetPoints();
	int second = list[1].GetPoints();
	int third = list[2].GetPoints();

	if (second < first) {
		swap(first, second);
	}
	if (third < second) {
		swap(second, third);
		if (second < first) {
			swap(first, second);
		}
	}
	for (int i = 3; i < leagueMembers; i++) {
		int points = list[i].GetPoints();

		if (points < first) {
			third = second;
			second = first;
			first = points;
		}
		else if (points < second && points != first) {
			third = second;
			second = points;
		}
		else if (points < third && points != second && points != first) {
			third = points;
		}
	}

	
	for (int j = 1; j <= 3; j++) {
		int threshold = (j == 1) ? first : (j == 2) ? second : third;

		for (int i = 0; i < leagueMembers; i++) {
			if (list[i].GetPoints() == threshold) {
				cout << "Name: " << list[i].GetName()
					<< " Points: " << list[i].GetPoints() << endl;
			}
		}
	}
}
void  DoAddTeamToList() { // adds a team to the current list
	int count;
	string restOfFile, line;

	ifstream inFile("LeagueInfo.dat");
	if (!inFile) {
		cout << "Failed to open file for reading." << endl;

	}

	inFile >> count;

	getline(inFile, line);
	while (getline(inFile, line)) {
		restOfFile += line + "\n";
	}
	inFile.close();


	++count;
	string newEntry;

	cout << "Please enter the name, the games played, the goals for the team, the goals against the team and the teams points you would like to add\n";
	cin.ignore();
	getline(cin, newEntry);
	restOfFile += newEntry + "\n";


	ofstream outFile("LeagueInfo.dat");
	if (!outFile) {
		cout << "Failed to open file for writing." << endl;
	}

	outFile << count << endl;
	outFile << restOfFile;

	cout << "Team added successfully." << endl;
}
void DoAddUser(void) { // adds user to a file it works by getting the entire content of the file into a string and then uses getline so blank spaces are included and writes the entire line to the file

	
	int count;
	string restOfFile, line;

	ifstream inFile("LeagueInfo.dat");
	if (!inFile) {
		cout << "Failed to open file for reading." << endl;

	}

	inFile >> count;

	getline(inFile, line); 
	while (getline(inFile, line)) {
		restOfFile += line + "\n";
	}
	inFile.close();


	++count;
	string newEntry;

	cout << "Please enter the Name of the team you want to add to the list\n";
	cin.ignore();
	getline(cin, newEntry);
	restOfFile += newEntry + "\n";

	
	ofstream outFile("UserInfo.dat");
	if (!outFile) {
		cout << "Failed to open file for writing." << endl;
		
	}

	outFile << count << endl; 
	outFile << restOfFile; 

	cout << "User added successfully." << endl;



}
void makeMenu(char acc) { // main menus and a switch statement for each function
	MenuClear();
	do
	{

		switch (tolower(acc))
		{
		case 'm': {
			ManagerMenu();
			cin >> mChoice;
			mChoice = validator(mChoice);
			MenuClear();
			switch (mChoice)
			{
			case 1: {
				DoInitializeTeamList();
				clearInputBuffer();
				MenuClear();
				break;
			}
			case 2: {
				DoDisplayLeague();
				clearInputBuffer();
				MenuClear();
				break;
			}
			case 3: {
				DoEnterMatchResult();
				clearInputBuffer();
				MenuClear();
				break;
			}
			case 4: {
				DoDeductPoints();
				clearInputBuffer();
				MenuClear();
				break;
			}
			case 5: {
				DoBestDefence();
				clearInputBuffer();
				MenuClear();
				break;
			}
			case 6: {
				DoRelegationZone();
				clearInputBuffer();
				MenuClear();
				break;
			}
			case 7: {
				DoAddTeamToList();
				clearInputBuffer();
				MenuClear();
				break;
			}
			case 8: {
				DoRemoveTeamFromList();
				clearInputBuffer();
				MenuClear();
				break;
			}
			case 9: {

				DoAddUser();
				clearInputBuffer();
				MenuClear();
				break;
			}
			case 10: {
				DoEditUser();
				SaveChanges();
				break;
			}
			case 0: {

				DoQuit();
				break;
			}
			default:

				cout << "Please enter valid choice.";
				break;

			}
			break;


		}
		case 'a': {

			AssistantMenu();
			cin >> aChoice;
			aChoice = validator(aChoice);
			MenuClear();
			switch (aChoice)
			{
			case 1: {
				DoDisplayLeague();
				clearInputBuffer();
				MenuClear();
				break;

			}
			case 2: {
				DoEnterMatchResult();
				clearInputBuffer();
				MenuClear();
				break;

			}
			case 3: {
				DoBestDefence();
				clearInputBuffer();
				MenuClear();
				break;

			}
			case 4: {

				DoRelegationZone();
				clearInputBuffer();
				MenuClear();
				break;
			}
			case 0: {
				
				DoQuit();
				break;
			}
			default:
			{

				cout << "Please enter valid choice.";
				break;

			}
			break;
			}

			break;
		default:
			break;
		}
		}
	} while (quit!='x');
}
void DoEditUser() { // edits the users password
	writein2();
	string name;
	bool noName=false;
	int password;
	cout << "Please enter the name of the user you would like to update the password.\n";
	cin >> name;
	for (int i = 0; i < UserAcc; i++)
	{
		if (logs[i].HasUser(name) == true)
		{
			noName = true;
			cout << "Please enter your new password: \n";
			cin >> password;
			logs[i].SetPassword(password);
			clearInputBuffer();
			MenuClear();
			break;
		}
	}
	if (!noName)
	{
		cout << "No user with the name: " << name << " found please try again.\n";
		clearInputBuffer();
		MenuClear();
	}
	SaveChanges();
}
int validator(int option) { // it is an int validator that if the cin failed or that the option input does not equal an int it displays the error catcher
	while (cin.fail() || int(option) != option) {
		system("cls");
		cout << "Invalid. Please enter a valid integer value: ";
		cin.clear();
		cin.ignore(100, '\n');
		cin >> option;
	}
	return option;
}
void DoEnterMatchResult() { // enter the match result of two teams and the goals they scored and updates the teams goals for and goals against
	writein();
	bool errorValidator=false,errorValidator2=false;
	string team1,team2;
	int goals1, goals2;
	cout << "please enter the name of the first team that has played and the goals they scored\n";
	cin >> team1;
	cin >> goals1;
	cout << "please enter the name of the second team has played and the goals they scored:\n";
	cin >> team2;
	cin >> goals2;
	for (int i = 0; i < leagueMembers; i++)
	{
		if (list[i].HasName(team1)==true)
		{
			errorValidator = true;
			list[i].UpdateResult(goals1);
			list[i].UpdateAgainst(goals2);
		}
	}
	for (int i = 0; i < leagueMembers; i++)
	{
		if (list[i].HasName(team2) == true)
		{
			errorValidator2 = true;
			list[i].UpdateResult(goals2);
			list[i].UpdateAgainst(goals1);
		}
	}
	if (!errorValidator&&!errorValidator2)
	{
		cout << "no home team with the name of: " << team1 << " found in the collection" << " and no away team with the name " << team2 << " found please try again";
	}
	writeout();
}
void writeout() { //writes out for the leagueinfo file

	ofstream outfile("LeagueInfo.dat");
	outfile << leagueMembers << endl;

	if (!outfile) {
		cout << "Failed to open file for writing." << endl;
		return;
	}
	for (int i = 0; i < leagueMembers; i++)
	{
		outfile << list[i].GetName() << " "
			<< list[i].GetGamesPlayed() << " "
			<< list[i].GetGoalsFor() << " "
			<< list[i].GetGoalsAgainst() << " "
			<< list[i].GetPoints() << endl;
	}

	outfile.close();
}
void SaveChanges() { // saves the changes done to the user info file
	ofstream outFile("UserInfo.dat");
	if (!outFile) {
		cout << "Failed to open file for writing." << endl;
		return;
	}
	outFile << UserAcc << endl;
	for (int i = 0; i < UserAcc; i++) {
		outFile << logs[i].GetUser() << " "
			<< logs[i].GetPassword() << " "
			<< logs[i].GetAccount() << endl;
	}
	outFile.close();
}
void DoRemoveTeamFromList() { //removes a team from the list by searching if the team names valid and makes the name a blank space and turns the into null
	writein();
	bool DeleteCheck=false;
	string TeamName;
	cout << "Please enter the name of the team you want to delete from the list\n";
	cin >> TeamName;
	for (int i = 0; i < leagueMembers; i++)
	{
		if (list[i].HasName(TeamName)==true)
		{
			list[i].ClearValue();
		}
	}
	if (!DeleteCheck)
	{
		cout << "No Team with the name: " << TeamName << "found.";
	}
	writeout();
}
void DoQuit(void) { //quits the program
	cout << "Goodbye thank you for using the program.";
	quit = 'x';
}
