#include "CFootballTeam.h"

CFootballTeam::CFootballTeam(void) {
	 m_Name="";
	 m_GamesPlayed=0;
	 m_GoalsFor=0;
	 m_GoalsAgainst=0;
	 m_Points=0;
}

CFootballTeam::CFootballTeam(string name) {
	m_Name = name;
	m_GamesPlayed = 0;
	m_GoalsFor = 0;
	m_GoalsAgainst = 0;
	m_Points = 0;
}
CFootballTeam::CFootballTeam(string name, int GamesPlayed,int GoalsFor,int GoalsAgainst, int Points) {
	m_Name = name;
	m_GamesPlayed = GamesPlayed;
	m_GoalsFor = GoalsFor;
	m_GoalsAgainst = GoalsAgainst;
	m_Points = Points;
}
void CFootballTeam::SetGamesPlayed(int GamesPlayed) {
	m_GamesPlayed = GamesPlayed;
}

void CFootballTeam::SetGoalsFor(int GoalsFor){
	m_GoalsFor = GoalsFor;
}

void CFootballTeam::SetGoalsAgainst(int GoalsAgainst){
	m_GoalsAgainst = GoalsAgainst;
}

void CFootballTeam::SetPoints(int Points){
	m_Points = Points;
}
string CFootballTeam::GetName(void) {
	return m_Name;
}

int CFootballTeam::GetGamesPlayed(void){
	return m_GamesPlayed;
}

int CFootballTeam::GetGoalsFor(void){
	return m_GoalsFor;
}

int CFootballTeam::GetGoalsAgainst(void){
	return m_GoalsAgainst;
}

int CFootballTeam::GetPoints(void){
	return m_Points;
}
void CFootballTeam::UpdateResult(int goals1) {
	m_GoalsFor = m_GoalsFor + goals1;
}
void CFootballTeam::UpdateAgainst(int goals1) {
	m_GoalsAgainst = m_GoalsAgainst + goals1;
}
bool CFootballTeam::HasName(string searchName) {
	if (m_Name==searchName)
	{
		return true;
	}
	else
	{
		return false;
	}
}
void CFootballTeam::ClearValue() {
	m_Name = "";
	m_GamesPlayed = m_GoalsFor = m_GoalsAgainst = m_Points = -1;
}
